<?php
session_start();
if(!isset($_SESSION['email'])) {//validate 
    header("Location: login.php");
}

if($_SESSION['role'] == "Admin") {

    if($_POST) {
       //connect to db
        require '../assn16/config/database.php';
        $pdo = Database::connect();

        $role = htmlspecialchars($_POST['role']);
        $fname = htmlspecialchars($_POST['fname']);
        $lname = htmlspecialchars($_POST['lname']);
        $email = htmlspecialchars($_POST['email']);
        $phone = htmlspecialchars($_POST['phone']);
        $password = htmlspecialchars($_POST['password']);
        $address = htmlspecialchars($_POST['address']);
        $address2 = htmlspecialchars($_POST['address2']);
        $city = htmlspecialchars($_POST['city']);
        $state = htmlspecialchars($_POST['state']);
        $zip_code = htmlspecialchars($_POST['zip_code']);

        $err = '';
        //https://stackoverflow.com/questions/22544250/php-password-validation#22544286
        if(!empty($_POST["password"])) {
            if (strlen($_POST["password"]) <= '15') {
                $err = "Your Password Must Contain At Least 16 Characters!";
                echo "<p>ERROR: $err </p><br>";
            }
            elseif(!preg_match("#[A-Z]+#",$password)) {
                $err = "Your Password Must Contain At Least 1 Capital Letter!";
                echo "<p>ERROR: $err </p><br>";
            }
            elseif(!preg_match("#[a-z]+#",$password)) {
                $err = "Your Password Must Contain At Least 1 Lowercase Letter!";
                echo "<p>ERROR: $err </p><br>";
            }
            //https://stackoverflow.com/questions/13970412/php-regex-for-a-string-of-special-characters/13970853
            elseif(!preg_match('/[#$%^!&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/', $password)) {
                $err = "Your Password Must Contain At Least 1 Special Character!";
                echo "<p>ERROR: $err </p><br>";
            }
            else {
                //pass the salt and hash please
                $salt = MD5(microtime());
                $hash = MD5($password.$salt);
                $_POST['password_hash'] = $hash;
                $_POST['password_salt'] = $salt;
                //username is not there
                $statement = "SELECT id FROM persons WHERE email =? ";
                $query=$pdo->prepare($statement);
                $query->execute(Array($email));
                $finalresult=$query->fetch(PDO::FETCH_ASSOC);
                //else
                if($finalresult != '' || $email == '') {
                    echo "<p> $email is taken.</p>";
                    $_POST["email"] = '';//reset on bust
                }
                //https://www.w3schools.com/php/php_form_url_email.asp
                elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    echo "<p>Try again.</p>";
                    $_POST["email"] = '';
                }else{
                    $_SESSION['create_post'] = $_POST;
                    header('Location: insert_persons.php');
                }
            }
        }
        else {
            $err = "Enter password ...  ";
            echo "<p> $err </p>";
        }
    }

    ?>

    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    </head>

    <h1>Create New User/Admin</h1>

    <form method='post'>
    <select name="role" id="role">
        <option value="User">User</option>
        <option value="Admin">Admin</option>
    </select> <br>

    First: <input name='fname' type='text' value = '<?php $fname ?>' required><br/>
    Last: <input name='lname' type='text' value = '<?php $lname ?>' required><br/>
    Email: <input name='email' type='text' value = '<?php $email ?>' required><br/>
    Phone: <input name='phone' type='text' value = '<?php $phone ?>' ><br/>
    Password: <input name='password' type='password' required><br/>
    Address: <input name='address' type='text' value = '<?php $address ?>' ><br/>
    Address2: <input name='address2' type='text' value = '<?php $address2 ?>' ><br/>
    City: <input name='city' type='text' value = '<?php $city ?>' ><br/>
    State: <input name='state' type='text' value = '<?php $state ?>' ><br/>
    Zip Code: <input name='zip_code' type='text' value = '<?php $zip_code ?>' ><br/>
    <br> 
        <button class="btn btn-lg btn-secondary" type="submit"
         name="submit">Submit</button>
         <a class='btn btn-lg btn-secondary' role='button' href='read_template.php'>Cancel</a>
    </form>

    <?php
}

else {
    ?>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
        </style>
    </head>
    <h1>As a USER, this feature is not available.</h1>
    <button class="btn btn-lg btn-primary" onclick="window.location.href = 'read_template.php'"
        name="list">Back</button>
    <?php
}
?>
