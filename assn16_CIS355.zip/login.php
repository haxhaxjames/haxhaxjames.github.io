<?php
    session_start();
    //print_r($_SESSION);
    //echo $_SESSION['username']=='admin@admin.com';
    $errMsg='';
    
    
    if (isset($_POST['login']) 
        && !empty($_POST['email'])
        && !empty($_POST['password'])) {
            
        $_POST['email'] = htmlspecialchars($_POST['email']);
        $_POST['password'] = htmlspecialchars($_POST['password']);  
        
        $key = $_POST['email'];
        
        require '../assn16/config/database.php';
        $pdo = Database::Connect();
        
        $statement = "SELECT password_salt FROM persons WHERE email =? ";
        $query=$pdo->prepare($statement);
        $query->execute(Array($key));
        $finalresult=$query->fetch(PDO::FETCH_ASSOC);
        
        $salt = $finalresult["password_salt"];
        $hash=MD5($_POST['password'].$salt);
        
        $statement = "SELECT id, role, email, password_hash, password_salt FROM persons " 
        . " WHERE email =? " . " AND password_hash =? " . " AND password_salt =? ";
        
        $query=$pdo->prepare($statement);
        
        $query->execute(Array($key, $hash, $salt));
        $finalresult=$query->fetch(PDO::FETCH_ASSOC);
        
        if($result) {
            $_SESSION['email'] = $finalresult['email'];
            $_SESSION['role'] = $finalresult['role'];
            $_SESSION['id'] = $finalresult['id'];
            header("Location: read_template.php");
        }
        
        }
        
        
        
?>
    <!DOCTYPE html>
<html lang="en-us">
        <head>
            <title>Crud Applet with Login</title>
            <meta charset ="utf-8" />
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
        </head>
        
        <body>
            <h1>Crud Applet with Login</h1>
            <h2>Login</h2>
            
            <form action="" method="post">
                
                <p style="color: red;"><?php echo $errMsg; ?></p>
                
                <input type="text" class="form-control"
                    name="username" placeholder="admin@admin.com"
                    required autofocus /> <br/>
                    
                <input type="password" class="form-control"
                    name="password" placeholder="admin"
                    required /> <br/>    
                
                <button class="btn btn-lg btn-primary btn-block"
                    type="submit" name="Login">Login</button> <br/>   
                    
                <button class="btn btn-lg btn-secondary btn-block" type="submit"
                onclick="location.href = 'register_persons.php';"
                name="Create">Join</button> <br> <br>    
                
            </form>
            
        </body>
        
</html>