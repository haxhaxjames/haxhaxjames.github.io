<head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    </head>

<?php

if($_POST) {
    $err = '';
    $fname = htmlspecialchars($_POST['fname']);
    $lname = htmlspecialchars($_POST['lname']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $password = htmlspecialchars($_POST['password']);
    $confPassword = htmlspecialchars($_POST['confPassword']);
    $address = htmlspecialchars($_POST['address']);
    $address2 = htmlspecialchars($_POST['address2']);
    $city = htmlspecialchars($_POST['city']);
    $state = htmlspecialchars($_POST['state']);
    $zip_code = htmlspecialchars($_POST['zip_code']);

    if($_POST["password"] != $_POST["confPassword"]) {
        $err = "Passwords do not match.";
        echo "<p> $err </p><br>";
        $_POST["password"] = '';
        $_POST["confPassword"] = '';

    }

    //https://stackoverflow.com/questions/22544250/php-password-validation#22544286
    elseif(!empty($_POST["password"]) && !empty($_POST["confPassword"])) {
        
        if (strlen($_POST["password"]) <= '15') {
            $err = "Passwords must be 16 chars long.";
            echo "<p> $err </p><br>";
            $_POST["password"] = '';
            $_POST["confPassword"] = '';
        } elseif (!preg_match("#[A-Z]+#", $password)) {
            $err = "Your Password Must Contain At Least 1 Capital Letter!";
            echo "<p>ERROR: $err </p><br>";
            $_POST["password"] = '';
            $_POST["confPassword"] = '';
        } elseif (!preg_match("#[a-z]+#", $password)) {
            $err = "Your Password Must Contain At Least 1 Lowercase Letter!";
            echo "<p>ERROR: $err </p><br>";
            $_POST["password"] = '';
            $_POST["confPassword"] = '';
        }

        //https://stackoverflow.com/questions/13970412/php-regex-for-a-string-of-special-characters/13970853
        elseif(!preg_match('/[#$%^!&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/', $password)) {
            $err = "Your Password Must Contain At Least 1 Special Character!";
            echo "<p> $err </p><br>";
            $_POST["password"] = '';
            $_POST["confPassword"] = '';
        } else {
            require '../database/database.php';
            $pdo = Database::connect();
            
            //Check to make sure username is not there
            $statement = "SELECT id FROM persons WHERE email =? ";
            $query=$pdo->prepare($statement);
            $query->execute(Array($email));
            $finalresult=$query->fetch(PDO::FETCH_ASSOC);
            
            if($result != '' || $email == '') {
                echo "<p> $email is taken.</p><br>";
            }
            //https://www.w3schools.com/php/php_form_url_email.asp
            elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo "<p>ERROR: Email is not formatted properly </p><br>";
                $_POST["email"] = '';
                $_POST["password"] = '';
                $_POST["confPassword"] = '';

            }
            
            else{
                session_start();
                $_SESSION['register_post'] = $_POST;
                header('Location: register_new_persons.php');
            }


        }
    }

    else {

        $err = "Please enter the password again: ";
        echo "<p> $err </p><br>";
        $_POST["password"] = '';
        $_POST["confPassword"] = '';
    }
}

?>
<h1>Register new user</h1>
<form method='post' action='' name = 'register_form'>

    First: <input name='fname' type='text' value = '<?php $fname ?>' required><br />
    Last: <input name='lname' type='text' value = '<?php $lname ?>' required><br />
    Email: <input name='email' type='text' value = '<?php $email ?>' required><br />
    Phone: <input name='phone' type='text' value = '<?php $phone ?>' ><br />
    Password: <input name='password' type='password' value = '<?php $password ?>' required><br />
    Re-Enter Password: <input name='confPassword' type='password' value = '<?php $confPassword ?>' required><br />
    Address: <input name='address' type='text' value = '<?php $address ?>' ><br />
    Address2: <input name='address2' type='text' value = '<?php $address2 ?>' ><br />
    City: <input name='city' type='text' value = '<?php $city ?>' ><br />
    State: <input name='state' type='text' value = '<?php $state ?>' ><br />
    Zip Code: <input name='zip_code' type='text' value = '<?php $zip_code ?>' ><br /><br> 

    <button class="btn btn-lg btn-primary" type="submit"
    name="submit">Submit</button>
    <a class='btn btn-lg btn-primary' role='button' href='login.php'>Cancel</a>

</form>
