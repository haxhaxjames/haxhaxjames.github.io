<?php

session_start();
if(!isset($_SESSION['email'])) {
    header("Location: login.php");
}

// check if value was posted
if($_POST){
  
    // include database and object file
    require '../assn16/config/database.php';
    $pdo = Database::connect();
      
    //use the url id value
    $id = $_GET['id'];
    
    $statement = "DELETE FROM persons WHERE id=$id";
    
    $pdo->query($statement); 
}
?>
<p>Deleted.</p><br>
<button class="btn btn-lg btn-primary" onclick="window.location.href = 'read_template.php'"
	name="list">Back</button>