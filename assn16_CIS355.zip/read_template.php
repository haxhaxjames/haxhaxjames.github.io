<?php
session_start();
if(!isset($_SESSION['email'])) {
    header("Location: login.php");
}
?>

<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
</head>
<h1>Displaying Persons</h1>

<p>You are using <?php echo $_SESSION['email']?> with <?php echo $_SESSION['role']?> permission.</p>
<br>
<br>
<br>
<br>
<body>
	<button class="btn btn-lg btn-primary" onclick="window.location.href = 'create_persons.php'"
	name="create">Create</button>

	<button class="btn btn-lg btn-primary" onclick="window.location.href = 'logout.php'"
	name="logout">Logout</button> <br> 
</body>

<?php 
//connect to db
require '../assn16/config/database.php';
$pdo = Database::connect();
//show records
$statement = "SELECT id, fname, lname, state FROM persons";
foreach ($pdo->query($statement) as $row) {
	$str = "";
    $str .= ' (' . $row['id'] . ') ' . $row['fname']. " " . $row['lname']. " " . $row['state']. " ";
	$str .= "<a href='read_template.php?id=" . $row['id'] . "'>Read</a> ";
	$str .= "<a href='form_to_update.php?id=" . $row['id'] . "'>Update</a> ";
	$str .= "<a href='form_to_delete.php?id=" . $row['id'] . "'>Delete</a> ";
	$str .=  '<br>';
	echo $str;
}
echo '<br />';
?>


