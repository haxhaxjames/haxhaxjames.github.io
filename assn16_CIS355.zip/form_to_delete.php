<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
}
if($_SESSION['role'] == "Admin") {
    ?>

    <h1> Are you sure? </h1>

    <?php
    require '../assn16/config/database.php';
    $pdo = Database::connect();
    //using the url id to select id to recrd deletion
    $id = $_GET['id'];
    $statement = "SELECT * FROM persons WHERE id=" . $id;
    $query = $pdo->prepare($statement);
    $query->execute();
    $finalresult = $query->fetch();

    ?>
    <form method='post' action='delete_persons.php?id=<?php echo $id ?>'>
        First: <input name='fname' type='text' value='<?php echo $finalresult['fname']; ?>' disabled><br /><br />
        Last: <input name='lname' type='text' value='<?php echo $finalresult['lname']; ?>' disabled><br/><br/>
        <input type="submit" name="Yes" value="Yes" />
        <a href="read_template.php"><input type="button" value="No"></a>
    </form>

    <?php
}
else {
    ?>
    <h1>As a USER, you cannot perform this action.</h1>
    <button class="btn btn-lg btn-primary" onclick="window.location.href = 'read_template.php'"
        name="list">Back</button>
    <?php
}
?>
