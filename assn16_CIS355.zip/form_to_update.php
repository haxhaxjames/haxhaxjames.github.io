<?php

session_start();
if(!isset($_SESSION['email'])) {
    header("Location: login.php");
}
if($_SESSION['role'] == "Admin" || $_SESSION['id'] == $_GET['id']) {
    
    require '../database/database.php';
    $pdo = Database::connect();

    if($_POST) {

        $role = htmlspecialchars($_POST['role']);
        $fname = htmlspecialchars($_POST['fname']);
        $lname = htmlspecialchars($_POST['lname']);
        $email = htmlspecialchars($_POST['email']);
        $phone = htmlspecialchars($_POST['phone']);
        $address = htmlspecialchars($_POST['address']);
        $address2 = htmlspecialchars($_POST['address2']);
        $city = htmlspecialchars($_POST['city']);
        $state = htmlspecialchars($_POST['state']);
        $zip_code = htmlspecialchars($_POST['zip_code']);
       
        $err = '';
        $id = $_GET['id'];

        $statement = "SELECT id FROM persons WHERE email =? ";
        $query=$pdo->prepare($statement);
        $query->execute(Array($email));
        $finalresult=$query->fetch(PDO::FETCH_ASSOC);

        $statement = "SELECT email FROM persons WHERE id =? ";
        $query=$pdo->prepare($statement);
        $query->execute(Array($id));
        $finalresult2=$query->fetch(PDO::FETCH_ASSOC);

        if( ($email != $finalresult2['email']) && $finalresult != '' ) {
            echo "<p>  $email taken.</p><br>";
        }

        //https://www.w3schools.com/php/php_form_url_email.asp
        elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "<p>Try again.</p><br>";
        }

        elseif($email == '') {
            echo "<p> Please fill in the required field.</p><br>";
        }

        else {

            $_SESSION['update_post'] = $_POST;
            header('Location: update_persons.php?id= '. $id);
        }

    }

    $id = $_GET['id'];
    $statement = "SELECT * FROM persons WHERE id=" . $id;
    $query=$pdo->prepare($statement);
    $query->execute();
    $finalresult = $query->fetch();


    ?>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    </head>
    <h1>Update Person</h1>

    <form method='post' action=''>
        <?php 
        if ($_SESSION['role'] == "Admin") {

            ?>
            <select name="role" id="role" value='<?php echo $result['role']; ?>' required>
            <option value="User">User</option>
            <option value="Admin">Admin</option>
            </select> <br><br>
            <?php 

        } else {
            
            ?>
            <select name="role" id="role" value='<?php echo $result['role']; ?>' required>
            <option value="User">User</option>
            </select> <br><br>
            <?php 
        }

        ?>

        ID: <input name='id' type='text' value='<?php echo $finalresult['id']; ?>' disabled><br><br>
        First: <input name='fname' type='text' value='<?php if($_POST) {echo $_POST['fname'];} else {echo $finalresult['fname'];} ?>' required><br><br>
        Last: <input name='lname' type='text' value='<?php if($_POST) {echo $_POST['lname'];} else {echo $finalresult['lname'];}  ?>' required><br><br>
        Email: <input name='email' type='text' value='<?php if($_POST) {echo $_POST['email'];} else {echo $finalresult['email'];}  ?>' required><br><br>
        Phone: <input name='phone' type='text' value='<?php if($_POST) {echo $_POST['phone'];} else {echo $finalresult['phone'];}  ?>'><br><br>
        Address: <input name='address' type='text' value='<?php if($_POST) {echo $_POST['address'];} else {echo $finalresult['address'];} ?>'><br><br>
        Address2: <input name='address2' type='text' value='<?php if($_POST) {echo $_POST['address2'];} else {echo $finalresult['address2'];}  ?>'><br><br>
        City: <input name='city' type='text' value='<?php if($_POST) {echo $_POST['city'];} else {echo $finalresult['city'];}  ?>'><br><br>
        State: <input name='state' type='text' value='<?php if($_POST) {echo $_POST['state'];} else {echo $finalresult['state'];}  ?>'><br><br>
        Zip Code: <input name='zip_code' type='text' value='<?php if($_POST) {echo $_POST['zip_code'];} else {echo $finalresult['zip_code'];}  ?>'><br><br>
        
        <button class="btn btn-lg btn-secondary" type="submit"
        name="submit">Submit</button>

        <a class='btn btn-lg btn-secondary' role='button' href='read_template.php'>Cancel</a>

    </form>

    <?php

} else {
    ?>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    </head>
    <h1>As a USER, this feature is unavailable.</h1>
    <button class="btn btn-lg btn-primary" onclick="window.location.href = 'read_template.php'"
        name="list">Back</button>

    <?php
}
?>
    
