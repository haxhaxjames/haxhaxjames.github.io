<head>
    <meta charset ="utf-8" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
</head>
<?php

require '../assn16/config/database.php';
$pdo = Database::connect();

session_start();
$_POST = $_SESSION['register_post'];

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$confPassword = $_POST['confPassword'];
$address = $_POST['address'];
$address2 = $_POST['address2'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip_code = $_POST['zip_code'];

$salt = MD5(microtime());
$hash = MD5($password.$salt);

$statement = "INSERT INTO persons (role, fname, lname, email, phone, password_hash, password_salt, address, address2, city, state, zip_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$query=$pdo->prepare($statement);
$query->execute(Array("User", $fname, $lname, $email, $phone, $hash, $salt, $address, $address2, $city, $state, $zip_code));

echo "<p>You're all set.'</p><br>";

?>
<button class="btn btn-lg btn-primary" onclick="window.location.href = 'login.php'"
name="list">Back</button>