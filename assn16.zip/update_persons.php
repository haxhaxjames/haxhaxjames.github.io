<?php
// get ID of the product to be edited

session_start();
if(!isset($_SESSION['email'])) {
    header("Location: login.php");
}

$id = isset($_POST['id']) ? $_POST['id'] : die('ERROR: missing ID.');
  
// include database and object files

  
// get database connection
require 'config/database.php';
$pdo = Database::connect();  

  
// if the form was submitted
if($_POST){

if ($_POST['role'] == Admin){
    
  
    $role = htmlspecialchars($_POST['role']);
    $fname = htmlspecialchars($_POST['fname']);
    $lname = htmlspecialchars($_POST['lname']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $address = htmlspecialchars($_POST['address']);
    $address2 = htmlspecialchars($_POST['address2']);
    $city = htmlspecialchars($_POST['city']);
    $state = htmlspecialchars($_POST['state']);
    $zip_code = htmlspecialchars($_POST['zip_code']);
 
    $statement = "UPDATE role='$role', fname='$fname', lname='$lname', email='$email', phone='$phone', address='$address', address2='$address2', city='$city', state='$state', zip_code='$zip_code' IN persons WHERE id=".$id;
    $query=$pdo->prepare($statement);
    $query->execute();
    
    
    
    }else{
    $fname = htmlspecialchars($_POST['fname']);
    $lname = htmlspecialchars($_POST['lname']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $address = htmlspecialchars($_POST['address']);
    $address2 = htmlspecialchars($_POST['address2']);
    $city = htmlspecialchars($_POST['city']);
    $state = htmlspecialchars($_POST['state']);
    $zip_code = htmlspecialchars($_POST['zip_code']);
 
    $statement = "UPDATE fname='$fname', lname='$lname', email='$email', phone='$phone', address='$address', address2='$address2', city='$city', state='$state', zip_code='$zip_code' IN persons WHERE id=".$id;
    $query=$pdo->prepare($statement);
    $query->execute();

    }
    
}  
?>
<button class="btn btn-lg btn-primary" onclick="window.location.href = 'read_template.php'"
name="list">Back</button>
