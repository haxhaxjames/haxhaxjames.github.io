<?php
    session_start();
    //print_r($_SESSION);
    //echo $_SESSION['username']=='admin@admin.com';
    $errMsg='';
    
    
    if (isset($_POST['login'])
        && !empty($_POST['email'])
        && !empty($_POST['password'])) {
            
        $_POST['email'] = htmlspecialchars($_POST['email']);
        $_POST['password'] = htmlspecialchars($_POST['password']);  
        
        $key = $_POST['email'];
        
        require 'config/database.php';
        $pdo = Database::Connect();
        
        
        $statement = "SELECT password_salt FROM persons WHERE email = ".$key;
        $query=$pdo->prepare($statement);
        $query->execute();
        $final=$query->fetch(PDO::FETCH_ASSOC);
        
        $salt = $final['password_salt'];
        $hash=MD5($_POST['password'].$salt);
        
        $statement = "SELECT id, role, email FROM persons " 
        . " WHERE email = ". $key . " AND password_hash = ". $hash;
        
        $query2=$pdo->prepare($statement);
        $query2->execute();
        $result = $query2->fetch(PDO::FETCH_ASSOC);
        $_SESSION['email'] = $_POST['email'];
        $_SESSION['role'] = $result['role'];
        $_SESSION['id'] = $result['id'];
        //print_r($query);
        if($query) {
            //print_r($_SESSION);
            //print_r($_POST);
            header("Location: read_template.php");
        }
        
        }else{
            $errMsg="Login Failure.";
        }
        
?>
    <!DOCTYPE html>
<html lang="en-us">
        <head>
            <title>Crud Applet with Login</title>
            <meta charset ="utf-8" />
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
        </head>
        
        <body>
            <h1>Crud Applet with Login</h1>
            <h2>Login</h2>
            
            <form action="" method="post">
                
                <p style="color: red;"><?php echo $errMsg; ?></p>
                
                <input type="text" class="form-control"
                    name="email" placeholder="admin@admin.com"
                    required autofocus /> <br/>
                    
                <input type="password" class="form-control"
                    name="password" placeholder="admin"
                    required /> <br/>    
                
                <button class="btn btn-lg btn-primary btn-block"
                    type="submit" name="login">Login</button> <br/>   
                    
                <button class="btn btn-lg btn-secondary btn-block" type="submit"
                onclick="location.href = 'register_persons.php';"
                name="create">Create</button> <br> <br>    
                
            </form>
            <a class='btn btn-lg btn-secondary' role='button' href='https://github.com/haxhaxjames/haxhaxjames.github.io'>Github File Storage</a>

        </body>
        
</html>