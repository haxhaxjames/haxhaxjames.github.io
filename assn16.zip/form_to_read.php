<?php

session_start();
if(!isset($_SESSION['email'])) {
    header("Location: login.php");
}

require 'config/database.php';
$pdo = Database::connect();

$id = $_GET['id'];
$statement = "SELECT * FROM persons WHERE id=" . $id;
$query=$pdo->prepare($statement);
$query->execute();
$finalresult = $query->fetch();

?>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
</head>

<h1>Person Info</h1>

<form method='post' action='read_template.php'>
    Role: <input name='role' type='text' value='<?php echo $finalresult['role']; ?>' disabled><br><br>
    ID: <input name='id' type='text' value='<?php echo $finalresult['id']; ?>' disabled><br><br>
    First: <input name='fname' type='text' value='<?php echo $finalresult['fname']; ?>' disabled><br><br>
    Last: <input name='lname' type='text' value='<?php echo $finalresult['lname']; ?>' disabled><br><br>
    Email: <input name='email' type='text' value='<?php echo $finalresult['email']; ?>' disabled><br><br>
    Address: <input name='address' type='text' value='<?php echo $finalresult['address']; ?>' disabled><br><br>
    Address2: <input name='address2' type='text' value='<?php echo $finalresult['address2']; ?>' disabled><br><br>
    City: <input name='city' type='text' value='<?php echo $finalresult['city']; ?>' disabled><br><br>
    State: <input name='state' type='text' value='<?php echo $finalresult['state']; ?>' disabled><br><br>
    Zip Code: <input name='zip_code' type='text' value='<?php echo $finalresult['zip_code']; ?>' disabled><br><br>
    
    <button class="btn btn-lg btn-primary" onclick="window.location.href = 'read_template.php'"
        name="list">Back</button>

</form>

