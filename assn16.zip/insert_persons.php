<?php
session_start();
if(!isset($_SESSION['email'])) {
    header("Location: login.php");
}
?>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
</head>
<?php

require 'config/database.php';
$pdo = Database::connect();

$_POST = $_SESSION['create_post'];

$role = $_POST['role'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$address = $_POST['address'];
$address2 = $_POST['address2'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip_code = $_POST['zip_code'];
$hash=$_POST['password_hash'];
$salt=$_POST['password_salt'];

$sql = "INSERT INTO persons (role, fname, lname, email, phone, password_hash, password_salt, address, address2, city, state, zip_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$query=$pdo->prepare($sql);
$query->execute(Array("User", $fname, $lname, $email, $phone, $hash, $salt, $address, $address2, $city, $state, $zip_code));

echo "<p>User is set.</p><br>";
?>

<button class="btn btn-lg btn-primary" onclick="window.location.href = 'read_template.php'"
name="list">Back</button>
